
2026-03-23-1

laznote - sticky note program written in lazarus.

available for linux and windows

rename exe file to change color, and name of notes.txt
laznote-yellow on linux, or laznote-yellow.exe on windows

window will be yellow, and file will be saved in Documents\laznote-yellow.txt

You can try other colors, too.

compiling
install lazarus
install: gtk2 sources, on void linux:
sudo xbps-install -S gtk+-devel

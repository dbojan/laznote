//2026-03-23-1

unit Unit1;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, ExtCtrls, Menus,
  StdCtrls;

type

  { TForm1 }

  TForm1 = class(TForm)
    Memo1: TMemo;
    MenuItem1: TMenuItem;
    MenuItem2: TMenuItem;
    PopupMenu1: TPopupMenu;
    TrayIcon1: TTrayIcon;
    procedure FormCreate(Sender: TObject);
    procedure Memo1Change(Sender: TObject);
    procedure MenuItem1Click(Sender: TObject);
    procedure MenuItem2Click(Sender: TObject);
    procedure TrayIcon1MouseUp(Sender: TObject; Button: TMouseButton;
      Shift: TShiftState; X, Y: Integer);
  private
       FSavePath: string;
       procedure ToggleWindow;
  public

  end;

var
  Form1: TForm1;

implementation

{$R *.lfm}

{ TForm1 }

procedure TForm1.ToggleWindow;
begin
  if Self.Visible then
    Self.Hide
  else
  begin
    Self.Show;
    Self.WindowState := wsNormal;
    Application.ProcessMessages;
    Self.BringToFront;
    Self.SetFocus;
  end;
end;


procedure TForm1.MenuItem1Click(Sender: TObject);
begin

 ToggleWindow;

end;

procedure TForm1.MenuItem2Click(Sender: TObject);
begin
  Application.Terminate;
end;


procedure TForm1.TrayIcon1MouseUp(Sender: TObject; Button: TMouseButton;
  Shift: TShiftState; X, Y: Integer);
begin
if Button = mbLeft then
  ToggleWindow;

  if Button = mbRight then
  PopupMenu1.PopUp;



end;

procedure TForm1.FormCreate(Sender: TObject);
var
ExeName, ColorPart: string;
begin

  ExeName := ExtractFileName(ParamStr(0));
  ExeName := ChangeFileExt(ExeName, '');
  Self.Caption := ExeName;

   FSavePath := IncludeTrailingPathDelimiter(GetUserDir) + 'Documents' + DirectorySeparator + ExeName + '.txt';

  if Pos('-', ExeName) > 0 then
  begin
    ColorPart := Copy(ExeName, Pos('-', ExeName) + 1, Length(ExeName));
    try
      Memo1.Color := StringToColor('cl' + ColorPart);
    except
      Memo1.Color := clDefault;
    end;
  end
  else
    Memo1.Color := clDefault;

  if FileExists(FSavePath) then
    Memo1.Lines.LoadFromFile(FSavePath);

  // Ensure the form's position can be set manually
  Self.Position := poDesigned;

  // X = Screen Width - Form Width - 10
  Self.Left := Screen.Width - Self.Width - 50;

  // Y = 10
  Self.Top := 50;


end;

procedure TForm1.Memo1Change(Sender: TObject);
begin
    if FSavePath <> '' then
    Memo1.Lines.SaveToFile(FSavePath);
end;

end.

